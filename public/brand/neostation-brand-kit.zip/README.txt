NeoStation brand kit

The mark
- An eye: a ring in two weights (bone and grey) with a red pupil. NeoStation watches over a whole retro
  library and shows it on every screen. The ring's two gaps sit on one diagonal; the eye looks and blinks
  along that same diagonal.

Logo
- neostation-logo.svg: for dark backgrounds (bone wordmark).
- neostation-logo-light.svg: for light backgrounds (ink wordmark, deeper red and grey).
- neostation-logo-mono-*.svg: one-colour versions for print or embroidery.
- neostation-isotype-{color,light,white,black}.svg: the eye alone (color = on dark, light = on light).
- neostation-appicon-{color,light,white,black}.svg: the eye on a square tile (platforms apply their own corner mask).
- Keep clear space around the logo equal to the height of the wordmark's capital N.
- Do not recolour, rotate, stretch or outline the eye, and do not swap the two ring weights.

Motion
- neostation-isotype-animated.svg / -animated-light.svg: the eye looks up-right, down-left, and blinks (4 s loop,
  SVG + CSS, stops when the viewer asks for reduced motion).
- motion/neostation-isotype-{dark,light}.{gif,mp4}: the same motion as GIF and MP4.
- Use the motion for loading, splash and social posts; keep the logo still in body text and print.

Colours
- Ink           #111216  background
- Bone          #F1EDE4  ring (thick) and wordmark on dark
- Grey          #B9B4A8  ring (thin) on dark
- Signal red    #FF5A4A  the pupil; the website's main action colour
- On light: ink #111216, grey #77736A, red #E8402F
Text on red or bone is ink (#111216).

Type
- Wordmark: Bai Jamjuree Bold Italic (SIL Open Font License).
- Interface and text: Bai Jamjuree; labels and data: JetBrains Mono.

The NeoStation name and logo identify the NeoStation project. Use them to refer to NeoStation,
not to suggest endorsement of other products.
