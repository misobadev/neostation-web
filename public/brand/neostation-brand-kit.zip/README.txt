NeoStation brand kit

Logo
- neostation-logo.svg: for dark backgrounds (bone wordmark).
- neostation-logo-light.svg: for light backgrounds (ink wordmark).
- neostation-logo-mono-*.svg: one-colour versions for print or embroidery.
- neostation-isotype-{color,white,black}.svg: the badge alone.
- neostation-appicon-{color,white,black}.svg: the badge on a square tile (platforms apply their own corner mask).
- Keep clear space around the logo equal to the height of the wordmark's capital N.
- Do not recolour, reorder, stretch, rotate or outline the bands, and do not use the yellow tile alone.

Colours
- Cabinet ink   #111216  background
- Bone          #F1EDE4  text and wordmark on dark
- Start yellow  #FFD23F  brand colour
- Red           #FF5A4A  badge band
- Blue          #4A74FF  badge band
Text on any brand colour is ink (#111216).

Type
- Wordmark: Bai Jamjuree Bold Italic (SIL Open Font License).
- Interface and text: Bai Jamjuree; labels and data: JetBrains Mono.

The NeoStation name and logo identify the NeoStation project. Use them to refer to NeoStation,
not to suggest endorsement of other products.
